from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from .forms import LoginForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from news.forms import PostForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)  # Создаем форму из данных POST
        if form.is_valid():  # Проверяем форму на валидность
            username = form.cleaned_data['username']  # Извлекаем имя пользователя
            password = form.cleaned_data['password']  # Извлекаем пароль
            user = authenticate(request, username=username, password=password)  # Проверка учетных данных пользователя
            if user is not None:  # Если пользователь найден
                login(request, user)  # Логируем пользователя
                return redirect('profile')  # Перенаправляем на домашнюю страницу
            else:
                form.add_error(None, 'Неверные логин или пароль')  # Если ошибка, добавляем ошибку в форму
    else:
        form = LoginForm()  # Если запрос GET, то создаем пустую форму

    return render(request, 'accounts/login.html', {'form': form})  # Рендерим шаблон с формой


@login_required
def profile_view(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user  # Связываем пост с текущим пользователем
            post.save()
            messages.success(request, 'Пост успешно добавлен!')
            return redirect('profile')  # Перенаправляем на страницу профиля
    else:
        form = PostForm()

    return render(request, 'accounts/profile.html', {'form': form})
