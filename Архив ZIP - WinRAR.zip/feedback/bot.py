import logging
import requests
from django.conf import settings

def send_telegram_message(name: str, email: str, review: str, chat_id: str = None):
    bot_token = settings.TELEGRAM_BOT_TOKEN
    chat_id = chat_id or settings.TELEGRAM_CHAT_ID

    if not bot_token or not chat_id:
        logging.error("Telegram bot token или chat_id не настроены.")
        return False

    message = (
        f"🔔 *Новое сообщение от пользователя:*\n\n"
        f"👤 *Имя:* {name}\n"
        f"📧 *Email:* {email}\n"
        f"💬 *Отзыв:* {review}\n"
    )

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown",
    }

    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        return True
    except requests.RequestException as e:
        logging.error(f"Ошибка при отправке сообщения в Telegram: {e}")
        logging.error(f"URL: {url}")
        logging.error(f"Data: {data}")
        if response is not None:
            logging.error(f"Response: {response.text}")
        return False
