from .models import reviews
from django.forms import ModelForm, TextInput, DateTimeInput, Textarea, ImageField, EmailField

class ArticleForm(ModelForm):
    class Meta:
        model = reviews
        fields = ['name', 'email', 'review']

        widgets = {
            "name": TextInput(attrs={
                "class": "form-control", 
                "placeholder": "Фамилия Имя"
            }),
            "email": TextInput(attrs={
                "class": "form-control", 
                "placeholder": "Почта"
            }),
            "review": Textarea(attrs={
                "class": "form-control",
                'placeholder': 'Текст'
            }),
        }