from django.db import models


class reviews(models.Model):
    name = models.CharField(max_length=100)
    email = models.TextField(max_length=100)
    review = models.TextField(max_length=1000)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.review
    

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
        ordering = ['-date']