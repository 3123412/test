from django.shortcuts import render, redirect
from .forms import ArticleForm
from .bot import send_telegram_message



def index(request):
    error = ''
    if request.method == "POST":
        form = ArticleForm(request.POST)
        if form.is_valid():
            form.save()

            name = request.POST.get('name', '')
            email = request.POST.get('email', '')
            text = request.POST.get('review', '')
            send_telegram_message(name, email, text)

            return redirect('home')
        else:
            error = 'Form is not valid'

    form = ArticleForm()

    data = {
        'form': form,
        'error': error
    }

    return render(request, 'feedback/riv.html', data)
