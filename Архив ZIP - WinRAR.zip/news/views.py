from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Post
from django.core.paginator import Paginator
# Create your views here.

def main(request):
    return render(request, 'news/news.html' )

def post_detail(request, post_id):
    # Получаем пост по ID, если не найден — возвращаем 404
    post = get_object_or_404(Post, id=post_id)

    return render(request, 'news/read.html', {'post': post})


def post_list(request):
    # Пагинация
    posts = Post.objects.all().order_by('-created_at')
    page_number = request.GET.get('page')
    paginator = Paginator(posts, 3)  # 3 поста на странице
    page_obj = paginator.get_page(page_number)

    return render(request, 'news/news.html', {'page_obj': page_obj})




# @login_required 
# def add(request):
#     error = ''
#     if request.method == "POST":
#         form = ArticleForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('news')
#         else:
#             error = 'Form is not valid'
            

#     form = ArticleForm()

#     data = {
#         'form': form,
#         'error': error
        
#     }


#     return render(request, 'news/add.html', data)
    
# # def edit(request):
# #     return render(request, 'news/edit.html' )
    
# # def delete(request):
# #     return render(request, 'news/delete.html' )
    
    